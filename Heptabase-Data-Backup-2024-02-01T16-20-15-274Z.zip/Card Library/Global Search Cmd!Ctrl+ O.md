---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - App
---
# Global Search `Cmd/Ctrl`\+ `O`

![](https://imgur.com/BlfcPkO.png)