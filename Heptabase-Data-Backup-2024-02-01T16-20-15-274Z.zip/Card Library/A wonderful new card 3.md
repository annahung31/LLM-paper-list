![Annotation 2023-08-22 101343.png](./A%20wonderful%20new%20card%203-assets/Annotation%202023-08-22%20101343.png)

Stack Exchange 跟  wikiHow 是很好的來源, 回答的 style 很一致

Reddit 則比較髒, 需要人工清理

在 paper section 2.1 有介紹如何清理這些 dataset


