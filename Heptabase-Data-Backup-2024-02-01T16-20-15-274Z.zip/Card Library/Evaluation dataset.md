# Evaluation dataset

- BIG-Bench

- BIG-Bench Hard (BBH)

   - semantic reasoning(e.g., “Movie Recommendation”),

   - numerical reasoning (e.g., “Multi-Step Arithmetic”)

   - combination of both (e.g., “Object Counting”)

   ![Screen Shot 2024-01-29 at 11.36.16 PM.png](./Evaluation%20dataset-assets/Screen%20Shot%202024-01-29%20at%2011.36.16%20PM.png)

Figure A1 Model outputs for a few reasoning tasks from BIG-Bench Hard (BBH).