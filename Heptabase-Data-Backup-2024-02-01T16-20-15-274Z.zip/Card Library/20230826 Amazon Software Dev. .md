## 20230826 Amazon Software Dev. 

1. 工作內容：→ LLM training data generation

2. 合作對象/形式：和 scientist 合作

3. 同事主管：怡安

4. 主管重視的：

Passion

Useful Debate 

High tense (高強度工作）



- 更具體來說是做什麼事？ -》 用什麼工具build什麼東西 （在JD裡面看到有Java Services (backend)）/技能

- 我們team有幾個人

- 這個職缺是怎麼產生的

- 和美國那邊合作的tempo是如何？通常什麼時間點會有request，有幾個小時可以做


