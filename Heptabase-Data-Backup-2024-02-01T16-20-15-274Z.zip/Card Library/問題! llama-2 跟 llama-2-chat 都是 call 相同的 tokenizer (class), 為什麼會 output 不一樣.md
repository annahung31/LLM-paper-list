# 問題: llama-2 跟 llama-2-chat 都是 call 相同的 tokenizer (class), 為什麼會 output 不一樣?

model 學到的東西不同

special token 不同