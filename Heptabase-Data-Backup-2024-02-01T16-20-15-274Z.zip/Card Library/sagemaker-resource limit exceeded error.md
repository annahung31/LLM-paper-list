---
tags:
  - aws
---
# sagemaker-resource limit exceeded error

想要 access GPU, 所以起了 ml.g4dn.xlarge, 但是起不了

![Screen Shot 2023-10-05 at 6.09.54 PM.png](./sagemaker-resource%20limit%20exceeded%20error-assets/Screen%20Shot%202023-10-05%20at%206.09.54%20PM.png)

按照這個 page 操作

<https://repost.aws/knowledge-center/sagemaker-resource-limit-exceeded-error>


