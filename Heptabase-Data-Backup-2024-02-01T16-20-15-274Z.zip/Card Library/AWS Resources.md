# AWS Resources





<https://aws.amazon.com/tw/getting-started/hands-on/machine-learning-tutorial-build-model-locally/>

<https://ithelp.ithome.com.tw/articles/10223505>

<https://ithelp.ithome.com.tw/articles/10280749>


