# 針對LLM ，訂自己的 goal 

[LLM for retrieval.md](./LLM%20for%20retrieval.md)

[RAG (retrieval augmented generation).md](./RAG%20\(retrieval%20augmented%20generation\).md)

[Data processing for LLM.md](./Data%20processing%20for%20LLM.md)

[Multi-turn Dialog 1.md](./Multi-turn%20Dialog%201.md)





什麼經驗是帶得走的？ 例如 distillation 

想像客戶會問我什麼，我要如何建議客戶




