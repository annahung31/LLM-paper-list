# 如何前處理 chat data?

在每一個 utterance 後面都加上一個 special **EOT token** (end-of-turn)