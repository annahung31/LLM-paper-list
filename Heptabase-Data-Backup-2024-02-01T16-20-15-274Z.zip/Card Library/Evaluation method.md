# Evaluation method

1. few-shot prompting: three examples from the same problem family are provided as context.

2. cross-task prompting: 拿不同 task 的 example 當作 few-shot.  意思是只要讓 model 知道 output format, 而不是學怎麼 reasoning.


