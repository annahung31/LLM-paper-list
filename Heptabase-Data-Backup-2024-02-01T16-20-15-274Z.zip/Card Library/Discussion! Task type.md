# Discussion: Task type

![Screen Shot 2024-01-29 at 11.00.15 PM.png](./Discussion!%20Task%20type-assets/Screen%20Shot%202024-01-29%20at%2011.00.15%20PM.png)

repeated code: 在某一些 task, 如果用程式處理的話，其實是相同的問題只是 input 不同，這類問題叫做 repeated code (例如：都是問去過哪些國家，只是每一題輸入的地名不同，或者都是多步驟的運算，只是數字不同）

new code: 每一題寫成 code 的時候解法不同



結果：python-only (repeated code),  python  100 % 過關 → 可想而知。充分展現優勢。

在 python + LM 上面，雖然沒辦法 100%, 但是仍比其他方法都好，甚至比人類平均好。



沒有明顯優勢的 task( 但也至少跟 CoT 一樣好了）:  NLP (第二個）



站在 CoT 的肩膀上（最差就是 fallback to LM reasoning)