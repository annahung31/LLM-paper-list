# Zero 3

會把 

- optimizer state

- gradient

- parameter

shard (分散)到多個 GPU 上, 避免 OOM

![Pasted 2023-09-07T02!38!40.620Z.png](./Zero%203-assets/Pasted%202023-09-07T02!38!40.620Z.png)