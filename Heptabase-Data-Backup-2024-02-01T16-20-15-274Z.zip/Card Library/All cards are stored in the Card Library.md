---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Concepts
Component:
  - Card
---
# All cards are stored in the **Card Library**.

![](https://imgur.com/pQeFka5.png)