---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - App
---
# Command Palette `Cmd/Ctrl`\+ `K`

![](https://imgur.com/FwPnE6B.png)