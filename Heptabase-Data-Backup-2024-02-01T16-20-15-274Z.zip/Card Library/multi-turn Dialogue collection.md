# multi-turn Dialogue collection

- 10 組 dialogue 是作者自己寫的

- 20 是從 Stack Exchange 改的