# Goal Map



- [ ] monitor cost 

- [ ] 使用 lambda 自動關閉 instance

- [ ] 使用 sagemaker deploy

- [ ] 使用 sagemaker finetune model

- [ ] 如何維護 service


