# QLoRA



Falcon 推出 180B 的模型, 在他的 blog 上列出不同情境所需要的 hardware 資源(也就是 GPU)

![image 1.png](./QLoRA-assets/image%201.png)

其中讓人驚豔的是 QLoRA 的 finetune 方法只需要 LoRA with zero-3 的 1/8

原本需要 16 張 A100, 使用 QLoRA 的話只要 2 張 

這個方法怎麼做到的呢?

跟 LoRA 相比, QLoRA 多做了:

1. 4-bit NormalFloat (NF4)

2. double quantization

3. Paged optimizers



[4 bit quantization.md](./4%20bit%20quantization.md)





### Reference

作者本人的介紹: <https://www.youtube.com/watch?v=LR3BmWCg7Y0> 




