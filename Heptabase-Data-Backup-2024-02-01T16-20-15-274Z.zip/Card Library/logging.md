# logging

用數字指定層級

transformers/src/transformers/utils/logging.py: get_verbosity

![image 5.png](./logging-assets/image%205.png)


