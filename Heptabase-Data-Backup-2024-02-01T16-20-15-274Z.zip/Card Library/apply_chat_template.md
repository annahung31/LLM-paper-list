# `apply_chat_template`

剛剛讀到一個 transformers issue, 

因為每個 model 的 prompt template 都不一樣

所以有人希望 transformers 可以把 prompt template 整進 model 裡面, 可以直接使用, 而不用自己去找

目前有一個 PR 專門處理這件事, 未來的某一個版本, 就會有 function 可以 call ( `apply_chat_template()`  )

用來取代今天早上提到的 private function  (`\_build_conversation_input_ids` )

適用於大部分具有 template 的 model, 不限於 LLaMA

[https://github.com/huggingface/transformers/pull/25323](https://github.com/huggingface/transformers/pull/25323)



`apply_chat_template` 使用範例

![Pasted 2023-09-06T07!49!49.244Z.png](./apply_chat_template-assets/Pasted%202023-09-06T07!49!49.244Z.png)



template 會被存在 `tokenizer.chat_template` , 你也可以自己更改

這個 template 會被存在 tokenizer_config.json 裡面

model owner 可以把 template 寫好 push 到 hub 上




