---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - Whiteboard
---
# Draw a box to select multiple cards.

![](https://imgur.com/LL0aCK1.png)