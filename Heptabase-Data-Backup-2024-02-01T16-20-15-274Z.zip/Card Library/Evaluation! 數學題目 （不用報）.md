# Evaluation: 數學題目 （不用報）

grade-school math (GSM8K) benchmark

表現很好，但是跟 Program of Thoughts 表現一樣好（因為是單純的運算問題，可以用 code 解決）


