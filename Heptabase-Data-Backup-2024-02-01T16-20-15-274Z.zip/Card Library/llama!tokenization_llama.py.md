# llama/tokenization_llama.py

![image.png](./llama!tokenization_llama.py-assets/image.png)

跟我 implement 的相同

差別在於 transformers 中的 code 適用於 inference (最後必須 user 結尾), 但是我寫的是 training ( assistant 結尾), 並且我還需要自己做 attention mask/ label