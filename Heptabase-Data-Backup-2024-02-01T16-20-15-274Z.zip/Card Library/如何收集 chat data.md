# 如何收集 chat data

好好選 instruction tuning 的 data 的話, 不需要那麼多筆data (大約 1000 就夠了)



在這些 data 中, outputs (responses) 的 style 是 align 的，只是 prompts diverse. 