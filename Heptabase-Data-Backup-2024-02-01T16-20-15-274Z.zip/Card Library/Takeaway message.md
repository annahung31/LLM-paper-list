# Takeaway message

- 站在 CoT 肩膀上，最差就是 fallback to LLM 原本的 reasoning 能力，所以可以預期會變好。

- 最適合的問題：大致邏輯符合寫 code 邏輯，但是有小部分很難 implement，可以借重 LM reasoning/sementic 能力

- 即使是對小模型/開源模型，應該也會有幫助

- 可能的缺點：inference 時間較長，需要搭配 python 執行環境。


