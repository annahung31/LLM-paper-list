---
tags:
  - aws
---
# IAM



*AWS* Identity and Access Management (*IAM*)

用來管理使用者的權限等級，限制使用者可以存取的 AWS 資源範圍



<https://godleon.github.io/blog/AWS/AWS-CSA-associate-IAM/>



設定權限：

- 推薦設定 group 的權限, 再把 user 加到 group 中

group:  

設定 permissions policites

因為是自己要用的，所以設定最寬的 admin access

![Screen Shot 2023-12-02 at 2.32.16 PM.png](./IAM-assets/Screen%20Shot%202023-12-02%20at%202.32.16%20PM.png)



設定完後，就可以使用 `aws iam list-users` 看到自己

![Screen Shot 2023-12-02 at 2.33.22 PM.png](./IAM-assets/Screen%20Shot%202023-12-02%20at%202.33.22%20PM.png)


