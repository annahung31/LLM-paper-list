---
tags:
  - aws
---
# 不同 region 的 instance 價格 

<https://www.concurrencylabs.com/blog/choose-your-aws-region-wisely/>

![Screen Shot 2023-10-05 at 6.35.40 PM.png](./不同%20region%20的%20instance%20價格%20-assets/Screen%20Shot%202023-10-05%20at%206.35.40%20PM.png)






