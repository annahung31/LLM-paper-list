# Ablation study









以下有幾個變形，從最基本到最完整

CoC (Python): Python is used to run the entire generated code and if the code is not executable, it is marked as failure

使用 python run 全部的 code，如果跑不了就是 fail  (a comparison to Program of Thoughts or [Program-Aided Language Models (llama example).md](./Program-Aided%20Language%20Models%20\(llama%20example\).md)) → 在 NLP task 很爛, 

---

CoC (try Python except LM)

CoC (try Python except LM state)

attempt to run the entire generated code with Python (rather than line by line) and if it fails, simulate the code execution with the LMulator, outputting a final answer or an intermediate state trace, respectively.

先把全部的 code 交給 python run, 如果 fail, 再把 code 交給 LMulator 做，看是要 output answer 還是 output 中間產物。

---

CoC (LM): the code is interpreted by an LMulator outputting the final answer (全部都交給 LM 做，output 答案）

CoC (LM state): the code is interpreted by an LMulator outputting a **state trace of intermediate steps** – this can be thought of as ScratchPad prompting for reasoning \[26\].   (全部都交給 LM做， output 中間產物 ）

---

CoC (Interweave) = CoC (Ours)：最完整的作法

---

（可以畫出一個倚賴程度光譜排序，最左邊是全 python, 最右邊是全 LM)





CoC (Python) - CoC (try Python except LM) / CoC (try Python except LM state) - CoC (Interweave)  -  CoC (LM state) / CoC (LM) - Direct / CoT





Q: CoC (Interweave) 跟  CoC (try Python except LM state)  的差異在哪？

A: CoC (try Python except LM state)  是先把 code 全部交給 python run, 如果 fail 再請 LM 執行

CoC (Interweave) 則是一開始就一行一行執行，在某一行 fail 的時候才交給 LM。執行完那一行，LM return 中間產物，再繼續由 python 往下執行。



TODO: 畫圖解釋



> ablation study 可以給出的 insight: 如果沒辦法做到 interleave, 有一些次佳的替代方案可以試試。例如CoC (try Python except LM)，其中如果有 maintain state 的話更好



![Screen Shot 2024-01-29 at 10.41.39 PM.png](./Ablation%20study-assets/Screen%20Shot%202024-01-29%20at%2010.41.39%20PM.png)

python only: python 可以全部跑完




