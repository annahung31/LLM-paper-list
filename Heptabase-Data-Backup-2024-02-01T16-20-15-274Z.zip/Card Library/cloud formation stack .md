# cloud formation stack 

這是什麼？

根據定義： A stack is a collection of AWS resources that you can manage as a unit. 

感覺上像是把我需要的東西集合在一起

Q: 包含什麼？ database, EC2 instance, s3

可以用 yaml/json 控制我要建什麼樣的環境 



Q: cloudFormation 要錢嗎？

A: 要，不過每個帳戶每個月可以有 1000 次免費操作（每次不超過30秒）


