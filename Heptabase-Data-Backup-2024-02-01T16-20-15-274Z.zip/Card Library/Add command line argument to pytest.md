# Add command line argument to pytest

### 基本用法

1. 在 tests root 新增一個 file: `conftest.py`, pytest 會在一開始自動執行這個 file

#### For Class 

1. 在 `conftest.py` 中設定 argument

   ```python
   import pytest
   
   def pytest_addoption(parser):
       parser.addoption("--name", action="store", default="default name")
   
   
   @pytest.fixture
   def get_name(request):
       setattr(request.cls, "name", request.config.getoption("--name"))
   ```

2. 在你的 test file 中:

   ```python
   
   @pytest.mark.usefixtures("get_name")
   class MyTest:
       def test_print(self):
           print(self.name) 
     
   ```



#### For function

1. 在 [`conftest.py`](conftest.py) 中設定 argument

   ```python
   import pytest
   
   def pytest_addoption(parser):
       parser.addoption("--name", action="store", default="default name")
   
   
   @pytest.fixture
   def get_name(request):
       return request.config.getoption("--name")
   ```

2. 在你的 test file 中:

   ```python
   def test_print(get_name):
       print(get_name)
   ```



### Issue

不能同時適用 class 跟 function:

In pytest, the **`request.cls`** attribute is only available when using class-based tests. It allows you to access the class instance and set attributes on it using **`setattr`**.

When using function-based tests, there is no class instance associated with the test function, so **`request.cls`** will be **`None`**. Therefore, you cannot use **`setattr(request.cls, "env", request.config.getoption("--env"))`** directly in the **`cur_env`** function.





目前的解法只能 function 跟 class 的使用分成兩個 fixture 寫, 再分別 call….

有更好的方式嗎?