---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Concepts
Component:
  - App
---
# Welcome to the beginner's tutorial of Heptabase!

The core purpose of Heptabase is to help you learn and conduct research more effectively, enabling you to develop a deep understanding of the topics that matter to you.

In Heptabase, there are three core concepts that are particularly important. They are:

- Invalid section

- Invalid section

- Invalid section

Once you have grasped these three concepts, you have already mastered the essence of Heptabase and can begin your learning and research. In this whiteboard, we will elaborate on each concept one by one.

If you're looking for more information about Heptabase, please check out our **[Public Wiki](https://www.notion.so/4dcb425de51c42c28d2fd57d0dbbdcdd?pvs=21)**. It contains our [version changelog](https://heptaplatforms.notion.site/Heptabase-Version-Changelog-29ea6db0b4ff4127b83d454742de86ad), [public roadmap](https://heptaplatforms.notion.site/Heptabase-Public-Roadmap-3f4fa6e915b1419487514a268e0a26c5), [use cases](https://heptaplatforms.notion.site/Use-Case-How-people-are-using-Heptabase-70c85a0c686945218427618549087629), and a **Chinese version (中文版)** of all tutorials.