---
tags:
  - tokenizer
---
# Tokenizer sharing 想討論的

1. 如何使用 HF 觀察 tokenizer 

2. 可以觀察的面向：

   1. 如何處理數字

   2. 如何處理縮排

   3. 如何處理繁體中文

3. 整理模型列表

4. 後記：討論遇到的困難


