# LLaMA-2

## LLaMA-2-chat finetuning

- 收集品質好的data很重要

- 最後收到 27540 個 data

- cosine scheduler: 2e-5

- weight decay = 0.1

- bsz = 64

- backpropagate only on answer tokens

- fine-tune the model for 2 epochs

- 
