---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - Whiteboard
---
# Right-click on selected cards to perform actions.

![](https://imgur.com/IU3i4WP.png)