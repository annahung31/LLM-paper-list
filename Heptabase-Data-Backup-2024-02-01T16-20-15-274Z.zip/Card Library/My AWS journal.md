# My AWS journal

### Day 1

目標是可以快速擁有我要的環境, 並且可以用 local vscode ssh 進去

每次重新打開環境的時候, 維持跟上次一樣



[cloud formation stack .md](./cloud%20formation%20stack%20.md)

[cloud watch.md](./cloud%20watch.md)

[Sagemaker studio.md](./Sagemaker%20studio.md)

[不同 region 的 instance 價格 .md](./不同%20region%20的%20instance%20價格%20.md)



### Day 2

[sagemaker-resource limit exceeded error.md](./sagemaker-resource%20limit%20exceeded%20error.md)

[lifecycle configuration.md](./lifecycle%20configuration.md)





### Day 3

放個假回來就燒了一萬塊……

找了半天發現是 instance 沒關

所以開始研究怎麼監控花費：

[Budget.md](./Budget.md)

[Cost Anomaly Detection.md](./Cost%20Anomaly%20Detection.md)

[IAM.md](./IAM.md)



### Day 4

今天學了怎麼用 lambda 關閉 instance: [lambda.md](./lambda.md)

只要再搭配 cloudwatch event, 就可以自動開關： <https://terahake.in/post/aws-workshop-ec2-timing/> Step4





### Goal

finetune Mistral on sagemaker

<https://www.philschmid.de/sagemaker-mistral>

![Screen Shot 2023-10-21 at 12.47.48 AM.png](./My%20AWS%20journal-assets/Screen%20Shot%202023-10-21%20at%2012.47.48%20AM.png)

沒有能力 pretrain 一個大的繁體中文 model，那可以 finetune 校正 model, 使他能夠分辨繁體中文跟簡體中文嗎？



- 跑一次 script ( 下週目標） 





### 1202

今天做到的事：

1. 可以用 ssh 從 mac local access 到 EC2 instance.  ( Documents/1_projects/my_aws_setting/to_aws.sh)

2. 下載並設定好 aws cli

3. 決定試用 DLAMI

4. 要開啟 EC2 isntance 的時候發現我沒有 quota → 申請中

5. 預定可以先使用最便宜的 GPU: NVIDIA GPU (G4dn)[https://aws.amazon.com/tw/ec2/instance-types/g4/](https://aws.amazon.com/tw/ec2/instance-types/g4/) 



下次繼續： <https://docs.aws.amazon.com/dlami/latest/devguide/launch.html#launch-from-console>



AWS Deep Learning Containers Images


