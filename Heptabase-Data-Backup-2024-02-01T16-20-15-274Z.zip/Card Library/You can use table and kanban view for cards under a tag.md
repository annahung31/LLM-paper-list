---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Concepts
Component:
  - Tag
  - Card
---
# You can use table and kanban view for cards under a tag.

At Heptabase, you can click on Tags in the left sidebar to see all your tags, and click on the "New Tag" button to add a new tag. When adding a new tag, you can choose to use either the table or kanban view as the default view for cards under that tag.

![](https://imgur.com/T3GV2Zm.png)

![](https://imgur.com/C01BcrN.png)