---
tags:
  - heptabase-tutorial
Level:
  - Expert
Type:
  - Advanced Guide
Component:
  - App
---
# **Four Practical Workflows for Beginners**

Here are four practical workflows that we believe are very useful for beginners. These workflows are related to thinking, capturing, reviewing, and writing, and can help you get started with Heptabase faster.

**Thinking** workflow: [The best way to acquire knowledge from readings.](https://www.notion.so/The-best-way-to-acquire-knowledge-from-readings-e4625c9b325c4074bd7ef47fa62a0d8d?pvs=21)

- Target audience: You spend a lot of time reading or taking lectures and want to deeply absorb and understand the knowledge you have learned.

**Collecting** Workflow: [Three ways to make sense of your fleeting thoughts in journal.](https://www.notion.so/Three-ways-to-make-sense-of-your-fleeting-thoughts-in-journal-0e134815efec4d51926084c481b11791?pvs=21)

- Target audience: You have scattered thoughts every day that you want to capture, but at the same time, want to be able to delve into these thoughts in depth in the future.

**Reviewing** Workflow: [Two steps to remember what you’ve learned even after a long time.](https://www.notion.so/Two-steps-to-remember-what-you-ve-learned-even-after-a-long-time-b41bdf7225f149aa8a52809348b48a4b?pvs=21)

- Target audience: You want to better review the notes you have previously written.

**Writing** Workflow: [A simple method to convert your thinking into writing.](https://www.notion.so/A-simple-method-to-convert-your-thinking-into-writing-e08a813483cb44b9b1b4123312a3e57e?pvs=21)

- Target audience: You have spent a lot of time pondering and organizing your ideas on the whiteboard and now want to use these ideas as material to write a well-structured article.