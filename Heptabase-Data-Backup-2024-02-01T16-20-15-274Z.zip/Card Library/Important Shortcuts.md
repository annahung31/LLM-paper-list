---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - App
---
# Important Shortcuts

> `Cmd` is for Mac, `Ctrl` is for Windows & Linux.

- [Command Palette Cmd!Ctrl+ K.md](./Command%20Palette%20Cmd!Ctrl+%20K.md)

- [Global Search Cmd!Ctrl+ O.md](./Global%20Search%20Cmd!Ctrl+%20O.md)

- [Keyboard shortcuts](https://heptaplatforms.notion.site/Keyboard-shortcuts-2a671d3bec7a4114a8218726cf2b1d5a)