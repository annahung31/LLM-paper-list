# LLM as Optimizers

Don’t know how to perform prompt engineering? Let LLM help you.





describe the optimization task in natural language.

**Steps**:

1. LLM generate new solutions from the prompt

2. new solutions are evaluated and added to the prompt



**Goal**: find instructions that maximize the task accuracy

**Result**: best prompts optimized by OPRO outperform human-designed prompts on some tasks.





There will be two LLM in the whole process: optimizer and scorer.

![image 4.png](./LLM%20as%20Optimizers-assets/image%204.png)


