# Introduction

在使用 LLM 的過程中 leverage coding 的邏輯優勢的作法，並不是新東西。

1. [Program-Aided Language Models (llama example).md](./Program-Aided%20Language%20Models%20\(llama%20example\).md) 

2. Program of Thoughts: 1. 生成 python code 2. 以 python 執行它. fail 就 fail 

3. ScratchPad: 就像面試的時候 dry run, 要 maintain 中間產物

4. 本篇： CoC- 處理那些 fail 的狀況 → 叫 LLM 做

![Screen Shot 2024-01-27 at 8.38.24 PM.png](./Introduction-assets/Screen%20Shot%202024-01-27%20at%208.38.24%20PM.png)




