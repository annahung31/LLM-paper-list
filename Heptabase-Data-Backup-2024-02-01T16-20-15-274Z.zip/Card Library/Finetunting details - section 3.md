# Finetunting details - section 3

- 15 epoch

- adamW

- without warmup steps

- init lr = 1e-5, linearly decay to 1e-6 by the end of training

- batch size = 32 (64 for smaller models)

- max length = 2048

- 使用 residual dropout

- 使用 dev set 來選擇 model (5th-10th epoch )

- perplexity 不一定可以代表 generation quality