# Method



基本精神：讓  python 一行一行執行，fail 的時候就改叫 LM 執行



step 1: LM generate code

step 2: python run code

step 3: if fail → call LM to get result

step 4: return final answer



![[./Component.md]]

