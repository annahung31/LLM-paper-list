---
tags:
  - aws
---
## Sagemaker studio

有 jupyter notebook

也有 terminal

notebook 裡面已經有一些套件了

![Screen Shot 2023-09-27 at 12.53.51 AM.png](./Sagemaker%20studio-assets/Screen%20Shot%202023-09-27%20at%2012.53.51%20AM.png)



terminal 有一個 default 的 conda 環境是 studio

Q: 要如何維護自定義的 conda env? 要存在哪？



Q: 怎麼收錢？

A: 一開始的使用次數是免費的，超過之後開始收費

<https://aws.amazon.com/tw/sagemaker/pricing/>

![Screen Shot 2023-09-27 at 12.58.51 AM.png](./Sagemaker%20studio-assets/Screen%20Shot%202023-09-27%20at%2012.58.51%20AM.png)

還不太確定到底會用多少



Q: cloudshell 是什麼？



JumpStart 有 llama-2 系列！

![Screen Shot 2023-09-27 at 1.00.55 AM.png](./Sagemaker%20studio-assets/Screen%20Shot%202023-09-27%20at%201.00.55%20AM.png)



可以從側邊欄關掉東西

![Screen Shot 2023-09-27 at 1.01.56 AM.png](./Sagemaker%20studio-assets/Screen%20Shot%202023-09-27%20at%201.01.56%20AM.png)


