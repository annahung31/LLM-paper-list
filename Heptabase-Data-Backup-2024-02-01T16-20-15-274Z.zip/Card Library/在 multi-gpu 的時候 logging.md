# 在 multi-gpu 的時候 logging

```python
if local_rank == 0:
    set_verbosity(10)
else:
    get_verbosity(50)

```






