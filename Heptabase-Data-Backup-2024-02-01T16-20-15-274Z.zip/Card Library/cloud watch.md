---
tags:
  - aws
---
### cloud watch

會有 log 可以看

![Screen Shot 2023-09-27 at 1.10.34 AM.png](./cloud%20watch-assets/Screen%20Shot%202023-09-27%20at%201.10.34%20AM.png)

也可以監控花錢

<https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#home:dashboards/Billing>