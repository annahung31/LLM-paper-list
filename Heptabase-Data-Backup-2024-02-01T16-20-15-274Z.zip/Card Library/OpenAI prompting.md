# OpenAI prompting

- If your task does have a “best” or  “correct” answer (factual use), then temperature  of 0 is the best.

- Template: 

   ```python
   INSTRUCTION\n\nText:\n\n{text input here}
   ```




