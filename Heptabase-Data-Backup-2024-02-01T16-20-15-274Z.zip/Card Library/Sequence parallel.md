# Sequence parallel

一筆 sample 如果只能放在單張 GPU, 就會受限於 memory 而有長度限制, 例如 512 token 

因此 sequence parallel 就是為了解決這個問題而產生的作法

在 sequence 的向度上, 將他切開分別送進不同張的 GPU

目前關於 sequence parallel 的 paper 有 2 篇:



1. Reducing Activation Recomputation in Large Transformer Models

   1. from NVIDIA (Megatron-LM)

   2. Aim to reduce memory usage

2. Sequence Parallelism: Long Sequence Training from System Perspective

   1. from ColosalAI

   2. Aim to break the limit of sequence length





### 比較

- 速度

- memory

- 通訊損耗

- 可達到的長度



### 實作



### 總結





### Reference

- <https://zhuanlan.zhihu.com/p/626553071>


