---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - Tag
---
# You can create groups for organizing your tags.

In addition to adding new tags, you can also click the "New Group" button to create groups for organizing your tags. For example, you can put the tags #meetings and #work-reports into the "Work" group, and the tags #blog-articles and #tax-returns into the "Life" group.

![](https://imgur.com/dG1Nm1E.png)