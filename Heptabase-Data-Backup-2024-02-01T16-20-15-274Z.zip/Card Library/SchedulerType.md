# SchedulerType

在 transformers/src/transformers/optimization.py 中, 顯示, 總共有 8 種 scheduler:

- linear with warmup

- cosine with warmup

- consine with restarts

….