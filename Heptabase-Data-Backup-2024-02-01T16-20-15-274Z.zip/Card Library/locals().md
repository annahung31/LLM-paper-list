# **locals()**

It is used to obtain the dictionary of the current local symbol table.

The symbol table is the data structure that is used to store all the information required to execute any program.


