### 4 bit quantization

32 bit → 4 bit = 1/8 saving

1. 先把 pretrained model 降到 4-bit

2. 搭配使用 LoRA, 只需要 finetune 少量的 weight



- 儲存用 4-bit, 運算用 BFloat16  



因為 model weight 通常都是 zero-centered normal distribution, 所以我們可以很容易的把 weight shift 到我們想要的值域裡面


