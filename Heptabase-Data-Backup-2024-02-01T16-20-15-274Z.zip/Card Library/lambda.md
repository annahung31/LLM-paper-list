# lambda

可以寫自動排程，例如定時開關 instance

官方 tutorial: <https://aws.amazon.com/tw/tutorials/run-serverless-code/>

用 lambda 自動開啟與關閉 EC2 instance: <https://terahake.in/post/aws-workshop-ec2-timing/>

### Script

在 Code source 中寫你要的 function

### setting

- Runtime: 選擇 script 的語言，例如 python

- Handler: 選定你所要執行的 function。例如，你的 script 寫在 lambda_function.py 中，有一個 function 叫做 lambda_handler。你希望 lambda 執行你的這個 function，則你的 handler 就要指定為這個 function，寫法跟 python import 類似： lambda_function.lambda_handler

   ![Screen Shot 2023-10-24 at 10.42.49 PM.png](./lambda-assets/Screen%20Shot%202023-10-24%20at%2010.42.49%20PM.png)

   ![Screen Shot 2023-10-24 at 10.44.09 PM.png](./lambda-assets/Screen%20Shot%202023-10-24%20at%2010.44.09%20PM.png)



### Testing

可以在 test 中撰寫 testcase，並實際執行，可以看到執行後的結果

- 可能會需要先 deploy 再執行test? 不知道為什麼改動完直接按 test 的話不會更新

### Monitor

有一個 tab 叫做 monitor, 可以從 cloudWatch 查看這個 function 被呼叫了幾次、歷時多久等等

![Screen Shot 2023-10-24 at 10.49.41 PM.png](./lambda-assets/Screen%20Shot%202023-10-24%20at%2010.49.41%20PM.png)





### 自動關閉 

```python
# =================================================================================
# == 將 YOUR_EC2_INSTANCE_REGION 修改成 "自己實行個體的區域(Region)" ==
# == 將 YOUR_EC2_INSTANCE_ID 修改成 "自己實行個體的ID(Instance ID)" (可新增多台) ==
# =================================================================================

# 開機(Start)的Lambda Function Code
import boto3
region = 'YOUR_EC2_INSTANCE_REGION(eg.us-east-1)'
instances = ['YOUR_EC2_INSTANCE_ID(eg.i-12345cb6de4f78g9h)']
ec2 = boto3.client('ec2', region_name=region)

def lambda_handler(event, context):
    ec2.start_instances(InstanceIds=instances)
    print('started your instances: ' + str(instances))

# ----------------------------------------------------------
# 關機(Stop)的Lambda Function Code
import boto3
region = 'YOUR_EC2_INSTANCE_REGION(eg.us-east-1)'
instances = ['YOUR_EC2_INSTANCE_ID(eg.i-12345cb6de4f78g9h)']
ec2 = boto3.client('ec2', region_name=region)

def lambda_handler(event, context):
    ec2.stop_instances(InstanceIds=instances)
    print('stopped your instances: ' + str(instances))

```




