# Discussion: 如果拿來打 instruction tuned model 呢？

就是我們知道的 chatGPT



使用步驟：

1. `write python code to help solve the problem, if it’s helpful`

2. 兩種方法： (有用 python interperter v.s 沒有）

   1. CoC (Python) :如果有寫 code → 拿來跑 → 有結果/error → 拿回來位給 model, 決定最終答案

   2. CoC (LM): 叫 model 模擬當 LMulator (ask the model to simulate the output of code execution as a LMulator)







(gpt-3.5-turbo 遠輸 gpt-4:  有一顆聰明的 base model 還是很重要）

(如果用 CoC interweave, 還是可以贏 gpt-4，只是不知道有沒有比較便宜)



![Screen Shot 2024-01-29 at 11.30.07 PM.png](./Discussion!%20如果拿來打%20instruction%20tuned%20model%20呢？-assets/Screen%20Shot%202024-01-29%20at%2011.30.07%20PM.png)

Q: 這裡的 tool use 是什麼意思不太懂