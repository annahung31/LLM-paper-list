# 處理 chat data


