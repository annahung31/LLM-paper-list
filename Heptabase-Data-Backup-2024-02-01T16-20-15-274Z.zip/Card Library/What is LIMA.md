# What is LIMA

- 65B LLaMA finetuned with 1000 carefully curated prompts and responses.

- NO RLHF

- Can generalize well to unseen tasks


