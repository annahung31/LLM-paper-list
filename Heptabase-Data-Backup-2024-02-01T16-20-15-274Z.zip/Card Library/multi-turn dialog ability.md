# multi-turn dialog ability

- 一樣從 65B LLaMA 開始, 用 1000 + 30 examples finetune