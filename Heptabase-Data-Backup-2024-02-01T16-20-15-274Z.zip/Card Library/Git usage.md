# Git usage

### Copy the content of a branch to a new local branch

```shell
git checkout old_branch
git branch new_branch
```

This will give you a new branch "new_branch" with the same state as "old_branch".

This command can be combined to the following:

```shell
git checkout -b new_branch old_branch
```



### error: Your local changes to the following files would be overwritten by checkout

1. I want to keep the change: 

   ```shell
   //option 1: add to stash
   git add xxx
   git stash
   
   //option 2: add to commit
   git add xxx
   git commit -m "xxx"
   ```

2. I don’t want to keep the change: (delete ALL the untracked files)

   ```shell
   git clean -n  // will show "ALL" files that are going to be deleted
   git clean -f 
   ```

3. 
