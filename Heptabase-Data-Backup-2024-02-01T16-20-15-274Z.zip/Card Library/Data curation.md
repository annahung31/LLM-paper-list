# Data curation

- 750: Community QA

- 200: 自創

- 50: sample from Super-Natural Instructions (NLP tasks such as summarization, paraphrasing…), 加以編輯修改 style

- 30 筆 hand-crafted dialogue chains



[A wonderful new card 5.md](./A%20wonderful%20new%20card%205.md)