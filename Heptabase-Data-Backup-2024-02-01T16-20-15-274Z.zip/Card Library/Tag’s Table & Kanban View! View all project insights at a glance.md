---
tags:
  - heptabase-tutorial
Level:
  - Expert
Type:
  - Advanced Guide
Component:
  - Tag
---
# [Tag’s Table & Kanban View](https://heptaplatforms.notion.site/Tag-s-Table-Kanban-View-View-all-project-insights-at-a-glance-d0680d7fca0a420a91f3099e52560244): View all project insights at a glance.

![](https://imgur.com/nLkVDX5.png)

In the getting started tutorial, we said: "When you want to organize a set of highly homogeneous cards, you can start by using tags. When you want to learn a topic deeply, you can create a whiteboard and then drag the cards related to that topic onto the whiteboard to connect and think."

If you are unsure whether to use tags or whiteboards to manage cards, we have a little trick to help you decide:

- If your main use case is learning and research, and you have a clear topic from the beginning, you can create cards directly on the whiteboard and then add tags to the cards that you want to manage.

- If your main use case is project management and you follow the practice of "organize first, think later," where you only start analyzing and comparing notes when the project has reached a certain stage, then you can use tags to manage your cards and move them to the whiteboard for thinking when needed.

At Heptabase, a tag is like a "database" for cards. When you add a tag to a card, it will be added to the corresponding tag database and acquire all the "properties" defined by that tag database.

For each tag database, you can click the "New view" button in the top left corner to add different views to present cards and their properties under the tag in different ways.

![](https://imgur.com/Qsm6uNu.png)

We currently support two types of views: Table and Kanban. We also support filtering cards in different views using different filter rules to display the cards you want.

![](https://imgur.com/j5FfEOW.png)

## **How to use table view**

![](https://imgur.com/nLkVDX5.png)

The table view of tags is perfect for presenting a large amount of key information about cards all at once. For instance, you may have a tag called #meetings, and for this tag, you have added properties such as "date," "summary," and "importance." When you use the table view to display the cards under this tag, you can easily see the dates, summaries, and importance of all the meeting notes without having to open each card individually.

Currently, we support nine different properties including Text, Number, Select, Multi-select, Date, Checkbox, URL, Phone, and Email. Compared to other database management systems, Heptabase has a unique advantage where, when a card has multiple tags, these tags can share the same properties! For example, you can share properties like "Summary" and "Importance" on both the #research-report and #meeting tags. This shared property feature allows you to have greater flexibility in managing your cards.

## **How to use kanban view**

![](https://imgur.com/pJ23yJJ.png)

Compared to the table view, the kanban view of tags is more useful for visualizing your project's progress. For example:

- If you are a product manager, you can use the kanban view to present different stages of ideas: New → Thinking → Thought completed → Design completed.

- If you are a writer, you can use the kanban view to manage different stages of your work: Draft → Writing → Done → Published.

- If you are an engineer, you can use the kanban view to manage tasks in different stages: Not Started → Next up → In Progress → Completed.

At Heptabase, whiteboards and tags are like brothers. Whiteboards provide a space for free thinking to help you learn and conduct research, while tags provide an organized system to help you manage a large number of cards. As long as you can make good use of these two core features, you will find that whether you're learning, researching, or working on projects, you can achieve twice the result with half the effort!