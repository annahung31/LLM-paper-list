# [Cost Anomaly Detection](https://us-east-1.console.aws.amazon.com/cost-management/home#/anomaly-detection/overview)



和 budget 的功能有何不同？