# Alignment

大部分的知識跟能力都是在 pretraining 建起來了， alignment 只是教模型要用什麼 format 來跟 user 互動