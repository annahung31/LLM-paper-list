---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - Card
---
# Math & Table blocks

## Tips

1. To create a math block, type `/` and then type `math`

2. To create a inline math, type `/` and then type `inline math`

3. To turn a text into an inline math, press `Cmd/Ctrl` + `Shift` + `E`

4. To create a table, type `/` and then type `table`

## Examples

KKT condition - Formulation cheatsheet:

- For maximization, with constraint $g(\mathbf{x}) \ge 0$: $L(\mathbf{x}, \lambda) = f(\mathbf{x}) + \lambda g(\mathbf{x})$.

- For minimization, with constraint $g(\mathbf{x}) \ge 0$: $L(\mathbf{x}, \lambda) = f(\mathbf{x}) - \lambda g(\mathbf{x})$.

- Noted that many literature states constraint in the form of $g(\mathbf{x}) \le 0$.

|  | $f(x)$ | $g(x)$ | 
|---|---|---|
| Maximization | 1 | $\lambda$ | 
| Minimization | 1 | $-\lambda$ | 

