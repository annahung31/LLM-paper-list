---
tags:
  - heptabase-tutorial
Level:
  - Beginner
Type:
  - Basic Operations
Component:
  - Tag
---
# You can use the shortcut `Cmd/Ctrl` + `T` to add a tag to an existing card.

![](https://imgur.com/JfD3HZK.png)