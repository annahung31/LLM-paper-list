---
tags:
  - aws
---
# Budget

設定 budget, 並且設定 alert, 當費用達到 N% 的 budget 時寄 email 通知。

另外，如果有起 EC2 instance 的話，可以設定 action，當花費高於設定值時就關閉 instance







<https://aws.amazon.com/tw/getting-started/hands-on/control-your-costs-free-tier-budgets/>