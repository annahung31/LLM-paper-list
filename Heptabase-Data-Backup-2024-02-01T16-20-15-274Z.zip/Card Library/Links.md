# Links



project: <https://chain-of-code.github.io/>

colab code:<https://colab.research.google.com/github/google-research/google-research/blob/master/code_as_policies/coc_demo.ipynb#scrollTo=s9SK_mER_ZOz>

github code: <https://github.com/google-research/google-research/blob/master/code_as_policies/coc_demo.ipynb>


