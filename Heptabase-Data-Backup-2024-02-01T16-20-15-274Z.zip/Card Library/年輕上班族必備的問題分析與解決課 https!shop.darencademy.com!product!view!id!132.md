**年輕上班族必備的問題分析與解決課** <https://shop.darencademy.com/product/view/id/132>



→ 不要上，上課內容是念稿，沒辦法專心聽