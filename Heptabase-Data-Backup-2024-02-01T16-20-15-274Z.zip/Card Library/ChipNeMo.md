# ChipNeMo

這篇 paper 很好的展示了, 要提升一個 general LLM 對特定 domain 的能力, 可以從三大部分下手:

1. Domain-Adaptive PreTraining(DAPT): 使用 “domain-adapted tokenizers“ 對open source base LLM 做 continued pretraining\
   DAPT, also known as continued pretraining with in-domain data

2. domain SFT: Instruction alignment with domain-specific instructions

3. RAG with trained domain-adapted retrieval model

Claim:

- 與其 finetune 70b 不如 DAPT 13b

- 當 domain-specific information 量大的時候, 只有使用 lora finetuning 可能會遇到學這個忘了那個的問題

> 	We posit that this phenomenon may be attributed to the necessity of training a large amount of parameters in order to accommodate a substantial volume of information, and the susceptibility of PEFT models to catastrophic forgetting \[33\].



1. 第一階段 DAPT

   1. 使用的 data 包含

      1. hardware code

      2. natural language datasets: hardware specifications, docs

   2. 新增新的token for domain-specific terms

      1. 用 domain data train tokenizer from scratch

      2. 從新的字典裏面找出原本沒有的 token

      3. 將這些新的 token 加到原本的 tokenizer 字典裡面, 他們的 embedding 用 average 來 initialize.  output layer weights initialize 為 0

      4. 利用這個 tokenizer 去做 autoregressive training

   



2. 第二階段: chat alignment

   1. 用 general purpose chat instruction dataset 就足夠讓 model 具備基本回答 chip design 問題的能力

   2. 另外還是有準備一份小量的 task-specific instruction data 來增強 mode 應答能力

3. RAG:

   1. RAG 本來就能夠讓模型紮根於特定問題的上下文, 在回答的準確度跟完整性上有顯著的進步

   2. 他們更進一步將 retrieval model pretrain 在 domain specific data 上, 因此效果更好





### 實際應用情境有三個:

1. engineering assistant chatbot

2. EDA tool script generation

3. bug summarization and analysis



### Evaluation

### Ablation study

使用小的 lr 才能在學新 data 同時保住舊有知識

> We hypothesize that a smaller learning rate played a dual role, facilitating the distillation of domain knowledge through DAPT while maintaining a balance that did not veer too far from the base model, thus preserving general natural language capabilities.


