---
tags:
  - aws
---
# instance 價格列表

G 系列： （最便宜）

<https://aws.amazon.com/tw/ec2/instance-types/g4/>

G4dn 執行個體特別具備 NVIDIA T4 GPU