### Program-Aided Language Models (llama example)

![Screen Shot 2024-02-01 at 11.24.15 PM.png](./Program-Aided%20Language%20Models%20(llama%20example)-assets/Screen%20Shot%202024-02-01%20at%2011.24.15%20PM.png)





paper: <https://arxiv.org/abs/2211.10435>\
llama code: <https://github.com/facebookresearch/llama-recipes/blob/main/examples/Prompt_Engineering_with_Llama_2.ipynb>