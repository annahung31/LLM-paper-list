Roughly equivalent to

````python
    ```
    for iterator in loader:
        for item in iterator:
            yield infer(item, **params)
    ```
````