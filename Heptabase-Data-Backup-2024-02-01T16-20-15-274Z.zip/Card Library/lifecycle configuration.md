# lifecycle configuration

自動設定一些東西，每次打開jupyter 的時候就會自動設定