# Discussion: 對小模型也有幫助

這裡比較的是一般的 chat completion model



![Screen Shot 2024-01-29 at 11.11.11 PM.png](./Discussion!%20對小模型也有幫助-assets/Screen%20Shot%202024-01-29%20at%2011.11.11%20PM.png)



a-1: text-ada-001,   

b-1: text-baggage-001, 

c-1: text-curie-001,

d-3: text-davinci-003   (GPT-3)

(在我們 sharing 的今天已經沒辦法 access 這些 model 了）

![Screen Shot 2024-01-29 at 11.15.56 PM.png](./Discussion!%20對小模型也有幫助-assets/Screen%20Shot%202024-01-29%20at%2011.15.56%20PM.png)

<https://platform.openai.com/docs/deprecations/>


