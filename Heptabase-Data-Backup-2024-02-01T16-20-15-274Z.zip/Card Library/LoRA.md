# LoRA

在原本的 adapter 做法中, 多加一個 factorized projection (因式分解)

假設原本的 linear projection 是 Y = XW

LoRA 會計算

![image 2.png](./LoRA-assets/image%202.png)

其中 L1, L2 相乘後的 size 跟 W 一樣



![image 3.png](./LoRA-assets/image%203.png)


