# Alpaca 

- An instruction-following llama model

- 





link: <https://github.com/tatsu-lab/stanford_alpaca>