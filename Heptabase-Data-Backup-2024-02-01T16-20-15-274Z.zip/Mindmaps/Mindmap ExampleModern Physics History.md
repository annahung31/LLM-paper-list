# **Mindmap Example**\
Modern Physics History
## 1803: Atomic indivisibility hypothesis
### **Proposer: Dalton**
## 1876: Cathode Ray Tube
### Gas discharge phenomenon: particles undergo deflection when passing through a magnetic field
- Discovery of electrons
### **Inventor: Karl Ferdinand Braun**
## 1887: Photoelectric Effect
### Short wavelength light (ultraviolet) colliding with metal will knock out electrons
- This is a way to take away (release) photon energy.
### **Discoverer: Hertz**
## 1895: Discovery of X-ray (high-frequency electromagnetic waves)
### Some photosensitive devices placed around the cathode ray tube are found to be sensitive to a source of light that is not understood (invisible). These are the energy (X-rays) emitted by electrons when decelerating.
- X-rays are absorbed more when passing through bones than through muscles, and the resulting contrast can be used for medical diagnosis and imaging.
### **Discoverer: Roentgen**
## 1897: The discovery of electrons within atoms, and the ability to measure electron mass and charge
### **Discoverer: J.J. Thomson**
## 1898 Thomson atomic model
### Atoms are electrically neutral, positive charges are distributed in a spherical shape, and electrons are evenly distributed within the sphere, like raisins mixed evenly together.
- Later overturned by quantum mechanics.
### **Proposer: J.J. Thomson**
## 1886-1898: Discovery of radiation and radioactive nuclei
### Unstable atomic nuclei release radioactive substances
- Three types of radiation: Alpha particles ($^{4}_{2}He$), Beta particles (free electrons), Gamma rays (high-frequency electromagnetic waves)
- Decades later, scientists discovered that in "stable" nuclei that exist naturally, the number of protons in lighter nuclei is roughly equal to the number of neutrons, while in heavier nuclei, the number of neutrons is greater than the number of protons to maintain stability.
  - The reason is that when the number of protons increases, the Coulomb repulsion between protons becomes stronger, and you need the action force between neutrons to counteract the Coulomb repulsion.
### **Discoverer: Becquerel & Curie**
## 1902: The energy released by natural radioactive decay is a million times greater than that released by chemical reactions
### **Proposer: Rutherford (a disciple of J.J. Thompson)**
