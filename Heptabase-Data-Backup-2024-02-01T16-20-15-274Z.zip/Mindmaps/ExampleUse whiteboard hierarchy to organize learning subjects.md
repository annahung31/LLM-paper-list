# **Example**\
Use **whiteboard hierarchy** to organize learning subjects
## Science
### Physics
### Chemistry
### **Biology**
## Technology
### AI
### Blockchain
### AR
### **Genetic Engineering**
### Robotics
## Computer Science
### Operating System
### Computer Architecture
### Data Structures & Algorithm
## International History
### **United States History**
### European History
### Chinese History
## Economics
### **Macro Economics**
### Micro Economics
