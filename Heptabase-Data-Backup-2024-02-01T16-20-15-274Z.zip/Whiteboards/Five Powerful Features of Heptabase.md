# Cards

[Sections! See the big picture of your learning topics.md](../Card%20Library/Sections!%20See%20the%20big%20picture%20of%20your%20learning%20topics.md)

[Nested Whiteboard! Organize learning topics with hierarchies and reusable cards.md](../Card%20Library/Nested%20Whiteboard!%20Organize%20learning%20topics%20with%20hierarchies%20and%20reusable%20cards.md)

[Tag’s Table & Kanban View! View all project insights at a glance.md](../Card%20Library/Tag’s%20Table%20&%20Kanban%20View!%20View%20all%20project%20insights%20at%20a%20glance.md)

[PDF Annotation & Readwise Integration! Bridge the gap between reading and thinking.md](../Card%20Library/PDF%20Annotation%20&%20Readwise%20Integration!%20Bridge%20the%20gap%20between%20reading%20and%20thinking.md)

[Mindmap! Effortlessly map out your learning.md](../Card%20Library/Mindmap!%20Effortlessly%20map%20out%20your%20learning.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps

[ExampleUse whiteboard hierarchy to organize learning subjects.md](../Mindmaps/ExampleUse%20whiteboard%20hierarchy%20to%20organize%20learning%20subjects.md)

[Mindmap ExampleModern Physics History.md](../Mindmaps/Mindmap%20ExampleModern%20Physics%20History.md)
