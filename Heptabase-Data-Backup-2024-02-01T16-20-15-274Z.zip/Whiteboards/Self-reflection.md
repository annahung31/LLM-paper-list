# Cards

[替每一年!季訂出閱讀目標.md](../Card%20Library/替每一年!季訂出閱讀目標.md)

[針對LLM ，訂自己的 goal .md](../Card%20Library/針對LLM%20，訂自己的%20goal%20.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
