# Cards

[Alpaca .md](../Card%20Library/Alpaca%20.md)

[QLoRA.md](../Card%20Library/QLoRA.md)

[LoRA.md](../Card%20Library/LoRA.md)

[gradient checkpointing.md](../Card%20Library/gradient%20checkpointing.md)

[4 bit quantization.md](../Card%20Library/4%20bit%20quantization.md)

[PEFT.md](../Card%20Library/PEFT.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
