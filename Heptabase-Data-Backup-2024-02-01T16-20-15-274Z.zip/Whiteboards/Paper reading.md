# Cards

[Alignment.md](../Card%20Library/Alignment.md)

[Data curation.md](../Card%20Library/Data%20curation.md)

[What is LIMA.md](../Card%20Library/What%20is%20LIMA.md)

[A wonderful new card 3.md](../Card%20Library/A%20wonderful%20new%20card%203.md)

[侷限.md](../Card%20Library/侷限.md)

[如何收集 chat data.md](../Card%20Library/如何收集%20chat%20data.md)

[想法.md](../Card%20Library/想法.md)

[My reading goal.md](../Card%20Library/My%20reading%20goal.md)

[multi-turn Dialogue collection.md](../Card%20Library/multi-turn%20Dialogue%20collection.md)

[Finetunting details - section 3.md](../Card%20Library/Finetunting%20details%20-%20section%203.md)

[multi-turn dialog ability.md](../Card%20Library/multi-turn%20dialog%20ability.md)

[自己標記的資料.md](../Card%20Library/自己標記的資料.md)

[如何前處理 chat data.md](../Card%20Library/如何前處理%20chat%20data.md)

[LLM as Optimizers.md](../Card%20Library/LLM%20as%20Optimizers.md)

[LLaMA-2.md](../Card%20Library/LLaMA-2.md)

[OpenAI prompting.md](../Card%20Library/OpenAI%20prompting.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
