# Cards

[Important Shortcuts.md](../Card%20Library/Important%20Shortcuts.md)

[Right-click empty space to create elements.md](../Card%20Library/Right-click%20empty%20space%20to%20create%20elements.md)

[Draw a box to select multiple cards.md](../Card%20Library/Draw%20a%20box%20to%20select%20multiple%20cards.md)

[Right-click on selected cards to perform actions.md](../Card%20Library/Right-click%20on%20selected%20cards%20to%20perform%20actions.md)

[Command Palette Cmd!Ctrl+ K.md](../Card%20Library/Command%20Palette%20Cmd!Ctrl+%20K.md)

[Global Search Cmd!Ctrl+ O.md](../Card%20Library/Global%20Search%20Cmd!Ctrl+%20O.md)

[Card.md](../Card%20Library/Card.md)

[Whiteboard.md](../Card%20Library/Whiteboard.md)

[Tag.md](../Card%20Library/Tag.md)

[Four Practical Workflows for Beginners.md](../Card%20Library/Four%20Practical%20Workflows%20for%20Beginners.md)

[Welcome to the beginner's tutorial of Heptabase.md](../Card%20Library/Welcome%20to%20the%20beginner's%20tutorial%20of%20Heptabase.md)

[Whiteboards don’t own your cards.md](../Card%20Library/Whiteboards%20don’t%20own%20your%20cards.md)

[A card can be placed in multiple whiteboards at the same time. .md](../Card%20Library/A%20card%20can%20be%20placed%20in%20multiple%20whiteboards%20at%20the%20same%20time.%20.md)

[All cards are stored in the Card Library.md](../Card%20Library/All%20cards%20are%20stored%20in%20the%20Card%20Library.md)

[Cards can mention each other.md](../Card%20Library/Cards%20can%20mention%20each%20other.md)

[You can use table and kanban view for cards under a tag.md](../Card%20Library/You%20can%20use%20table%20and%20kanban%20view%20for%20cards%20under%20a%20tag.md)

[You can create groups for organizing your tags.md](../Card%20Library/You%20can%20create%20groups%20for%20organizing%20your%20tags.md)

[You can use the shortcut Cmd!Ctrl + T to add a tag to an existing card.md](../Card%20Library/You%20can%20use%20the%20shortcut%20Cmd!Ctrl%20+%20T%20to%20add%20a%20tag%20to%20an%20existing%20card.md)

[List blocks.md](../Card%20Library/List%20blocks.md)

[Media & File blocks.md](../Card%20Library/Media%20&%20File%20blocks.md)

[Math & Table blocks.md](../Card%20Library/Math%20&%20Table%20blocks.md)

[Code blocks.md](../Card%20Library/Code%20blocks.md)

[A wonderful new card.md](../Card%20Library/A%20wonderful%20new%20card.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
