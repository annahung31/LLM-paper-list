# Cards

[Introduction.md](../Card%20Library/Introduction.md)

[Ablation study.md](../Card%20Library/Ablation%20study.md)

[Links.md](../Card%20Library/Links.md)

[Discussion! 對小模型也有幫助.md](../Card%20Library/Discussion!%20對小模型也有幫助.md)

[Evaluation dataset.md](../Card%20Library/Evaluation%20dataset.md)

[Takeaway message.md](../Card%20Library/Takeaway%20message.md)

[Discussion! Task type.md](../Card%20Library/Discussion!%20Task%20type.md)

[Discussion! 如果拿來打 instruction tuned model 呢？.md](../Card%20Library/Discussion!%20如果拿來打%20instruction%20tuned%20model%20呢？.md)

[Method.md](../Card%20Library/Method.md)

[Program-Aided Language Models (llama example).md](../Card%20Library/Program-Aided%20Language%20Models%20(llama%20example).md)

[A wonderful new card 20.md](../Card%20Library/A%20wonderful%20new%20card%2020.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
