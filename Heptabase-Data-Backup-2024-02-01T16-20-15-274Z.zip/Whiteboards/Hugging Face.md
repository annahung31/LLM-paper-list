# Cards

[llama!tokenization_llama.py.md](../Card%20Library/llama!tokenization_llama.py.md)

[A wonderful new card 12.md](../Card%20Library/A%20wonderful%20new%20card%2012.md)

[問題! pipeline 如何 encode rule.md](../Card%20Library/問題!%20pipeline%20如何%20encode%20rule.md)

[問題! llama-2 跟 llama-2-chat 都是 call 相同的 tokenizer (class), 為什麼會 output 不一樣.md](../Card%20Library/問題!%20llama-2%20跟%20llama-2-chat%20都是%20call%20相同的%20tokenizer%20(class),%20為什麼會%20output%20不一樣.md)

[preprocess.md](../Card%20Library/preprocess.md)

[ConversationalPipeline.md](../Card%20Library/ConversationalPipeline.md)

[apply_chat_template.md](../Card%20Library/apply_chat_template.md)

[問題! 如何在 trainingarguments 中設定 lr scheduler.md](../Card%20Library/問題!%20如何在%20trainingarguments%20中設定%20lr%20scheduler.md)

[SchedulerType.md](../Card%20Library/SchedulerType.md)

[在 multi-gpu 的時候 logging.md](../Card%20Library/在%20multi-gpu%20的時候%20logging.md)

[logging.md](../Card%20Library/logging.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
