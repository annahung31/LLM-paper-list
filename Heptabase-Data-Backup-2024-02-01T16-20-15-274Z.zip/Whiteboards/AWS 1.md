# Cards

[IAM.md](../Card%20Library/IAM.md)

[Budget.md](../Card%20Library/Budget.md)

[Cost Anomaly Detection.md](../Card%20Library/Cost%20Anomaly%20Detection.md)

[lifecycle configuration.md](../Card%20Library/lifecycle%20configuration.md)

[不同 region 的 instance 價格 .md](../Card%20Library/不同%20region%20的%20instance%20價格%20.md)

[sagemaker-resource limit exceeded error.md](../Card%20Library/sagemaker-resource%20limit%20exceeded%20error.md)

[cloud formation stack .md](../Card%20Library/cloud%20formation%20stack%20.md)

[Sagemaker studio.md](../Card%20Library/Sagemaker%20studio.md)

[cloud watch.md](../Card%20Library/cloud%20watch.md)

[AWS Resources.md](../Card%20Library/AWS%20Resources.md)

[Goal Map.md](../Card%20Library/Goal%20Map.md)

[My AWS journal.md](../Card%20Library/My%20AWS%20journal.md)

[lambda.md](../Card%20Library/lambda.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
