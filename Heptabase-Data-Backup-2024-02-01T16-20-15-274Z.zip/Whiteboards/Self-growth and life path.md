# Cards

[想上的課程.md](../Card%20Library/想上的課程.md)

[我的建議有可能影響決策，那應該審慎考慮之後再發言.md](../Card%20Library/我的建議有可能影響決策，那應該審慎考慮之後再發言.md)

[Plan ! Goal.md](../Card%20Library/Plan%20!%20Goal.md)

[針對LLM ，訂自己的 goal .md](../Card%20Library/針對LLM%20，訂自己的%20goal%20.md)

[畫自己的ML!AI graph.md](../Card%20Library/畫自己的ML!AI%20graph.md)

[成就感來自被需要.md](../Card%20Library/成就感來自被需要.md)

[真誠的溝通可以促進合作.md](../Card%20Library/真誠的溝通可以促進合作.md)

[替每一年!季訂出閱讀目標.md](../Card%20Library/替每一年!季訂出閱讀目標.md)

[尋找天賦與熱情的系統化做法 https!shop.darencademy.com!product!view!id!57 （實體+線上）.md](../Card%20Library/尋找天賦與熱情的系統化做法%20https!shop.darencademy.com!product!view!id!57%20（實體+線上）.md)

[用經營公司的思維經營你的人生  https!shop.darencademy.com!product!view!id!116 .md](../Card%20Library/用經營公司的思維經營你的人生%20%20https!shop.darencademy.com!product!view!id!116%20.md)

[年輕上班族必備的問題分析與解決課 https!shop.darencademy.com!product!view!id!132.md](../Card%20Library/年輕上班族必備的問題分析與解決課%20https!shop.darencademy.com!product!view!id!132.md)

# PDF Cards

# Highlights

# Texts

# Images

# Videos

# Audios

# Mindmaps
