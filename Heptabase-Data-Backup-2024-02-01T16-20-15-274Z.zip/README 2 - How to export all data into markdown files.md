Heptabase cares about the future-proofing of your notes. If you want to export all your data and use it in other software, follow the instructions below
1. Open the Heptabase app and click the settings button located at the top-left of the sidebar.
2. Click the 'Backup & Sync' option, then click the 'Export Now' button.
This will export all of your cards, journals, highlights, mindmaps, and whiteboards into markdown files. It will also export all the PDFs, images, videos, audios, and file attachments you have added to Heptabase. Tags and properties will be exported as YAML in markdown files.